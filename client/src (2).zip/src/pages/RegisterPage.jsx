// src/pages/RegisterPage.jsx
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Eye, EyeOff, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import api from "../api/axios";
import useAuthStore from "../store/authStore";

const INTERESES = [
  "React", "Node.js", "MongoDB", "Docker", "Python",
  "Machine Learning", "Figma", "UI/UX", "JavaScript",
  "TypeScript", "AWS", "IoT", "Arduino", "Ciberseguridad",
  "SQL", "Linux",
];

const OBJETIVOS = [
  "Networking", "Proyectos", "Investigación",
  "Emprendimiento", "Estudio",
];

const inputStyle = {
  width: "100%", height: 48,
  background: "#141414",
  border: "1px solid #2d2d2d",
  borderRadius: 12,
  padding: "0 16px",
  fontSize: 14, color: "#fff",
  outline: "none", boxSizing: "border-box",
  transition: "all 180ms ease",
};

const labelStyle = {
  display: "block", fontSize: 13,
  fontWeight: 500, color: "#E5E7EB", marginBottom: 8,
};

const focusHandlers = {
  onFocus: e => { e.currentTarget.style.borderColor = "#6366f1"; e.currentTarget.style.boxShadow = "0 0 0 3px rgba(99,102,241,0.12)"; },
  onBlur:  e => { e.currentTarget.style.borderColor = "#2d2d2d"; e.currentTarget.style.boxShadow = "none"; },
};

export default function RegisterPage() {
  const navigate = useNavigate();
  const { setAuth } = useAuthStore();

  const [step, setStep]       = useState(1);
  const [error, setError]     = useState("");
  const [loading, setLoading] = useState(false);

  // Paso 1
  const [fullName, setFullName] = useState("");
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [showPwd, setShowPwd]   = useState(false);

  // Institución
  const [institution, setInstitution]         = useState("");
  const [campuses, setCampuses]               = useState([]);
  const [campus, setCampus]                   = useState("");
  const [loadingCampus, setLoadingCampus]     = useState(false);

  // Paso 2
  const [career, setCareer]         = useState("");
  const [faculty, setFaculty]       = useState("");
  const [semester, setSemester]     = useState(1);
  const [bio, setBio]               = useState("");
  const [interests, setInterests]   = useState([]);
  const [objectives, setObjectives] = useState([]);

  const handleEmailBlur = async () => {
    if (!email.includes("@") || !email.includes(".")) return;
    setLoadingCampus(true);
    setInstitution(""); setCampuses([]); setCampus("");
    try {
      const { data } = await api.get(`/institutions/campuses?email=${email}`);
      setInstitution(data.institution);
      setCampuses(data.campuses);
    } catch {
      setInstitution(""); setCampuses([]);
    } finally {
      setLoadingCampus(false);
    }
  };

  const toggleChip = (item, list, setList) => {
    setList(prev => prev.includes(item) ? prev.filter(i => i !== item) : [...prev, item]);
  };

  const goToStep2 = () => {
    if (!fullName || !email || !password || !campus) {
      setError("Completa todos los campos"); return;
    }
    if (password.length < 8) {
      setError("La contraseña debe tener al menos 8 caracteres"); return;
    }
    setError(""); setStep(2);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const res = await api.post("/auth/register", {
        fullName, email, password, campus,
        career, faculty, semester: Number(semester),
        bio, interests, objectives,
      });
      setAuth(res.data.usuario, res.data.token);
      navigate("/feed");
    } catch (err) {
      setError(err.response?.data?.message || "Error al registrarse");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      width: "100vw", minHeight: "100vh",
      background: "#080808",
      display: "flex",
      fontFamily: "'Inter', sans-serif",
      overflow: "hidden",
    }}>

      {/* ── PANEL IZQUIERDO ── */}
      <motion.div
        initial={{ opacity: 0, x: -32 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        style={{
          width: "50%", minHeight: "100vh",
          background: "#0a0a0a",
          borderRight: "1px solid #141414",
          display: "flex", flexDirection: "column",
          justifyContent: "space-between",
          padding: "48px",
          position: "relative", overflow: "hidden",
        }}
      >
        <div style={{
          position: "absolute", bottom: -200, left: -200,
          width: 600, height: 600, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(139,92,246,0.08) 0%, transparent 70%)",
          filter: "blur(60px)", pointerEvents: "none",
        }} />

        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
            <path d="M6 4h10c3.3 0 6 2.7 6 6s-2.7 6-6 6h-2l6 8H16l-5.5-8H10v8H6V4z M10 8v4h6a2 2 0 000-4h-6z" fill="white"/>
          </svg>
          <span style={{ fontWeight: 700, fontSize: 18, color: "#fff", letterSpacing: "-0.02em" }}>
            LinkUp
          </span>
        </div>

        {/* Centro */}
        <div>
          <motion.p
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            style={{ fontSize: 13, color: "#8b5cf6", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }}
          >
            Únete a LinkUp
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            style={{ fontSize: "clamp(2rem, 3.5vw, 3rem)", fontWeight: 800, color: "#fff", lineHeight: 1.1, letterSpacing: "-0.03em", margin: "0 0 20px 0" }}
          >
            Tu red empieza<br />aquí.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            style={{ fontSize: 15, color: "#666", lineHeight: 1.7, maxWidth: 360 }}
          >
            Crea tu perfil y conecta con estudiantes que comparten tus intereses, facultad y objetivos.
          </motion.p>
        </div>

        {/* Steps indicator */}
        <motion.div
          initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          style={{ display: "flex", flexDirection: "column", gap: 12, maxWidth: 360 }}
        >
          {[
            { n: 1, label: "Información básica", desc: "Nombre, email, contraseña y campus" },
            { n: 2, label: "Tu perfil", desc: "Carrera, intereses y objetivos" },
          ].map(s => (
            <div key={s.n} style={{
              display: "flex", alignItems: "center", gap: 14,
              padding: "14px 18px",
              background: step >= s.n ? "rgba(99,102,241,0.08)" : "#111",
              border: `1px solid ${step >= s.n ? "rgba(99,102,241,0.2)" : "#1f1f1f"}`,
              borderRadius: 14,
              transition: "all 300ms",
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: "50%", flexShrink: 0,
                background: step > s.n ? "#6366f1" : step === s.n ? "rgba(99,102,241,0.15)" : "#1a1a1a",
                border: `1px solid ${step >= s.n ? "#6366f1" : "#2a2a2a"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 13, fontWeight: 600,
                color: step > s.n ? "#fff" : step === s.n ? "#6366f1" : "#444",
              }}>
                {step > s.n ? <Check size={14} /> : s.n}
              </div>
              <div>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: step >= s.n ? "#fff" : "#444" }}>{s.label}</p>
                <p style={{ margin: "2px 0 0 0", fontSize: 11, color: "#555" }}>{s.desc}</p>
              </div>
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* ── PANEL DERECHO ── */}
      <motion.div
        initial={{ opacity: 0, x: 32 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        style={{
          width: "50%", minHeight: "100vh",
          display: "flex", alignItems: "center", justifyContent: "center",
          padding: "48px",
          overflowY: "auto",
        }}
      >
        <div style={{ width: "100%", maxWidth: 420 }}>

          {/* Nav */}
          <div style={{ marginBottom: 40 }}>
            <Link to="/" style={{ fontSize: 13, color: "#666", textDecoration: "none" }}>
              ← Home
            </Link>
          </div>

          {/* Progress bar */}
          <div style={{ display: "flex", gap: 6, marginBottom: 36 }}>
            {[1, 2].map(s => (
              <motion.div key={s}
                animate={{ background: step >= s ? "linear-gradient(90deg, #6366f1, #8b5cf6)" : "#1f1f1f" }}
                transition={{ duration: 0.3 }}
                style={{ flex: 1, height: 3, borderRadius: 4 }}
              />
            ))}
          </div>

          {/* Eyebrow */}
          <p style={{ fontSize: 12, fontWeight: 600, color: "#8b5cf6", letterSpacing: "0.08em", textTransform: "uppercase", margin: "0 0 12px 0" }}>
            {step === 1 ? "Crear cuenta" : "Tu perfil"}
          </p>
          <h2 style={{ fontSize: 30, fontWeight: 700, color: "#fff", letterSpacing: "-0.02em", margin: "0 0 8px 0" }}>
            {step === 1 ? "Join LinkUp" : "Personaliza tu perfil"}
          </h2>
          <p style={{ fontSize: 14, color: "#666", margin: "0 0 32px 0" }}>
            {step === 1 ? "Tu información básica para comenzar." : "Cuéntanos quién eres y qué buscas."}
          </p>

          {/* ── PASO 1 ── */}
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                style={{ display: "flex", flexDirection: "column", gap: 16 }}
              >
                {/* Nombre */}
                <div>
                  <label style={labelStyle}>Nombre completo</label>
                  <input type="text" placeholder="Juan Pérez"
                    value={fullName} onChange={e => setFullName(e.target.value)}
                    style={inputStyle} {...focusHandlers}
                  />
                </div>

                {/* Email */}
                <div>
                  <label style={labelStyle}>Correo institucional</label>
                  <input type="email" placeholder="juan@itm.edu.co"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    onBlur={handleEmailBlur}
                    style={inputStyle} {...focusHandlers}
                  />
                  {loadingCampus && <p style={{ fontSize: 12, color: "#666", marginTop: 6 }}>Detectando institución...</p>}
                  {institution && <p style={{ fontSize: 12, color: "#34D399", marginTop: 6 }}>✓ {institution}</p>}
                </div>

                {/* Password */}
                <div>
                  <label style={labelStyle}>Contraseña</label>
                  <div style={{ position: "relative" }}>
                    <input type={showPwd ? "text" : "password"} placeholder="Mínimo 8 caracteres"
                      value={password} onChange={e => setPassword(e.target.value)}
                      style={{ ...inputStyle, paddingRight: 48 }} {...focusHandlers}
                    />
                    <button type="button" onClick={() => setShowPwd(v => !v)}
                      style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "#666", cursor: "pointer", display: "flex", alignItems: "center", padding: 0 }}
                    >
                      {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {/* Campus */}
                {campuses.length > 0 && (
                  <div>
                    <label style={labelStyle}>Campus</label>
                    <select value={campus} onChange={e => setCampus(e.target.value)}
                      style={{ ...inputStyle, cursor: "pointer" }}
                      {...focusHandlers}
                    >
                      <option value="">Selecciona tu campus</option>
                      {campuses.map(c => (
                        <option key={c.id} value={c.id}>{c.label} — {c.city}</option>
                      ))}
                    </select>
                  </div>
                )}

                {error && <p style={{ fontSize: 12, color: "#ef4444", margin: 0 }}>{error}</p>}

                <motion.button type="button" onClick={goToStep2}
                  whileHover={{ y: -2, boxShadow: "0 10px 30px rgba(99,102,241,0.3)" }}
                  whileTap={{ scale: 0.98 }}
                  style={{
                    width: "100%", height: 48, borderRadius: 12,
                    background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
                    border: "none", color: "#fff",
                    fontSize: 14, fontWeight: 600, cursor: "pointer",
                  }}
                >
                  Siguiente →
                </motion.button>

                <p style={{ textAlign: "center", fontSize: 14, color: "#666", margin: 0 }}>
                  ¿Ya tienes cuenta?{" "}
                  <Link to="/login" style={{ color: "#6366f1", fontWeight: 600, textDecoration: "none" }}>
                    Sign In
                  </Link>
                </p>
              </motion.div>
            )}

            {/* ── PASO 2 ── */}
            {step === 2 && (
              <motion.form
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                onSubmit={handleSubmit}
                style={{ display: "flex", flexDirection: "column", gap: 16 }}
              >
                {/* Carrera y Facultad */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <div>
                    <label style={labelStyle}>Carrera</label>
                    <input type="text" placeholder="Ing. de Sistemas"
                      value={career} onChange={e => setCareer(e.target.value)}
                      style={inputStyle} {...focusHandlers}
                    />
                  </div>
                  <div>
                    <label style={labelStyle}>Facultad</label>
                    <input type="text" placeholder="Ing. y Sistemas"
                      value={faculty} onChange={e => setFaculty(e.target.value)}
                      style={inputStyle} {...focusHandlers}
                    />
                  </div>
                </div>

                {/* Semestre */}
                <div>
                  <label style={labelStyle}>Semestre</label>
                  <select value={semester} onChange={e => setSemester(e.target.value)}
                    style={{ ...inputStyle, cursor: "pointer" }} {...focusHandlers}
                  >
                    {Array.from({ length: 12 }, (_, i) => i + 1).map(s => (
                      <option key={s} value={s}>Semestre {s}</option>
                    ))}
                  </select>
                </div>

                {/* Bio */}
                <div>
                  <label style={labelStyle}>
                    Bio <span style={{ color: "#555", fontWeight: 400 }}>(opcional)</span>
                  </label>
                  <textarea
                    placeholder="Cuéntanos quién eres..."
                    value={bio} onChange={e => setBio(e.target.value)}
                    maxLength={300}
                    style={{
                      width: "100%", minHeight: 80, resize: "none",
                      background: "#141414", border: "1px solid #2d2d2d",
                      borderRadius: 12, padding: "12px 16px",
                      color: "#fff", fontSize: 14, outline: "none",
                      boxSizing: "border-box", transition: "all 180ms ease",
                      fontFamily: "inherit",
                    }}
                    onFocus={e => { e.target.style.borderColor = "#6366f1"; e.target.style.boxShadow = "0 0 0 3px rgba(99,102,241,0.12)"; }}
                    onBlur={e => { e.target.style.borderColor = "#2d2d2d"; e.target.style.boxShadow = "none"; }}
                  />
                </div>

                {/* Intereses */}
                <div>
                  <label style={labelStyle}>Intereses</label>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {INTERESES.map(item => (
                      <motion.button key={item} type="button"
                        onClick={() => toggleChip(item, interests, setInterests)}
                        whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                        style={{
                          padding: "6px 14px", borderRadius: 20,
                          fontSize: 12, fontWeight: 500, cursor: "pointer",
                          transition: "all 150ms",
                          background: interests.includes(item) ? "linear-gradient(135deg, #6366f1, #8b5cf6)" : "#141414",
                          border: `1px solid ${interests.includes(item) ? "transparent" : "#2d2d2d"}`,
                          color: interests.includes(item) ? "#fff" : "#666",
                        }}
                      >
                        {item}
                      </motion.button>
                    ))}
                  </div>
                </div>

                {/* Objetivos */}
                <div>
                  <label style={labelStyle}>¿Qué buscas en LinkUp?</label>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {OBJETIVOS.map(item => (
                      <motion.button key={item} type="button"
                        onClick={() => toggleChip(item, objectives, setObjectives)}
                        whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                        style={{
                          padding: "6px 14px", borderRadius: 20,
                          fontSize: 12, fontWeight: 500, cursor: "pointer",
                          transition: "all 150ms",
                          background: objectives.includes(item) ? "linear-gradient(135deg, #6366f1, #8b5cf6)" : "#141414",
                          border: `1px solid ${objectives.includes(item) ? "transparent" : "#2d2d2d"}`,
                          color: objectives.includes(item) ? "#fff" : "#666",
                        }}
                      >
                        {item}
                      </motion.button>
                    ))}
                  </div>
                </div>

                {error && <p style={{ fontSize: 12, color: "#ef4444", margin: 0 }}>{error}</p>}

                <div style={{ display: "flex", gap: 10 }}>
                  <button type="button" onClick={() => setStep(1)}
                    style={{
                      flex: 1, height: 48, borderRadius: 12,
                      background: "#141414", border: "1px solid #2d2d2d",
                      color: "#666", fontWeight: 500, cursor: "pointer",
                      fontSize: 14, transition: "border-color 200ms",
                    }}
                    onMouseEnter={e => e.currentTarget.style.borderColor = "#444"}
                    onMouseLeave={e => e.currentTarget.style.borderColor = "#2d2d2d"}
                  >
                    ← Volver
                  </button>
                  <motion.button type="submit" disabled={loading}
                    whileHover={!loading ? { y: -2, boxShadow: "0 10px 30px rgba(99,102,241,0.3)" } : {}}
                    whileTap={!loading ? { scale: 0.98 } : {}}
                    style={{
                      flex: 2, height: 48, borderRadius: 12,
                      background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
                      border: "none", color: "#fff",
                      fontSize: 14, fontWeight: 600,
                      cursor: loading ? "not-allowed" : "pointer",
                      display: "flex", alignItems: "center", justifyContent: "center",
                    }}
                  >
                    {loading ? (
                      <div style={{ width: 16, height: 16, border: "2px solid rgba(255,255,255,0.3)", borderTopColor: "#fff", borderRadius: "50%", animation: "spin 0.7s linear infinite" }} />
                    ) : "Crear cuenta"}
                  </motion.button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      <style>{`
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        @media (max-width: 768px) {
          .auth-split { flex-direction: column !important; }
        }
        select option { background: #141414; color: #fff; }
      `}</style>
    </div>
  );
}