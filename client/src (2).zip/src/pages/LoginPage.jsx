// src/pages/LoginPage.jsx
import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import { motion } from "framer-motion";
import api from "../api/axios";
import useAuthStore from "../store/authStore";

export default function LoginPage() {
  const navigate = useNavigate();
  const { setAuth, token } = useAuthStore();

  const [email, setEmail]             = useState("");
  const [password, setPassword]       = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState("");

  useEffect(() => {
    if (token) navigate("/feed");
  }, [token, navigate]);

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError("Completa todos los campos");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const res = await api.post("/auth/login", { email, password });
      setAuth(res.data.usuario, res.data.token);
      navigate("/feed");
    } catch (err) {
      setError(err.response?.data?.message || "Error al iniciar sesión");
    } finally {
      setLoading(false);
    }
  };

  const isReady = email.trim() && password.trim();

  return (
    <div style={{
      width: "100vw",
      height: "100vh",
      background: "#080808",
      display: "flex",
      overflow: "hidden",
      fontFamily: "'Inter', sans-serif",
    }}>

      {/* ── PANEL IZQUIERDO ── */}
      <motion.div
        initial={{ opacity: 0, x: -32 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        style={{
          width: "50%",
          height: "100%",
          background: "#0a0a0a",
          borderRight: "1px solid #141414",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: "48px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Blob decorativo */}
        <div style={{
          position: "absolute",
          bottom: -200,
          left: -200,
          width: 600,
          height: 600,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(99,102,241,0.08) 0%, transparent 70%)",
          filter: "blur(60px)",
          pointerEvents: "none",
        }} />

        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
            <path d="M6 4h10c3.3 0 6 2.7 6 6s-2.7 6-6 6h-2l6 8H16l-5.5-8H10v8H6V4z M10 8v4h6a2 2 0 000-4h-6z" fill="white"/>
          </svg>
          <span style={{ fontWeight: 700, fontSize: 18, color: "#fff", letterSpacing: "-0.02em" }}>
            LinkUp
          </span>
        </div>

        {/* Centro — texto */}
        <div>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            style={{ fontSize: 13, color: "#6366f1", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }}
          >
            Bienvenido de nuevo
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            style={{ fontSize: "clamp(2rem, 3.5vw, 3rem)", fontWeight: 800, color: "#fff", lineHeight: 1.1, letterSpacing: "-0.03em", margin: "0 0 20px 0" }}
          >
            Conecta.<br />Aprende.<br />Crece.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            style={{ fontSize: 15, color: "#666", lineHeight: 1.7, maxWidth: 360 }}
          >
            Descubre estudiantes con tus mismos intereses, facultad y objetivos dentro de tu universidad.
          </motion.p>
        </div>

        {/* Tarjeta decorativa de perfil */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.7 }}
          style={{
            background: "#111",
            border: "1px solid #1f1f1f",
            borderRadius: 20,
            padding: "20px 24px",
            display: "flex",
            alignItems: "center",
            gap: 16,
            maxWidth: 360,
          }}
        >
          <div style={{
            width: 48, height: 48, borderRadius: "50%",
            background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 20, flexShrink: 0,
          }}>
            🎓
          </div>
          <div>
            <p style={{ margin: 0, fontSize: 14, fontWeight: 600, color: "#fff" }}>87% de compatibilidad</p>
            <p style={{ margin: "2px 0 0 0", fontSize: 12, color: "#666" }}>Con 3 estudiantes en tu campus</p>
          </div>
          <div style={{
            marginLeft: "auto",
            background: "rgba(99,102,241,0.15)",
            border: "1px solid rgba(99,102,241,0.3)",
            borderRadius: 8, padding: "4px 10px",
            fontSize: 11, fontWeight: 600, color: "#6366f1",
          }}>
            Nuevo
          </div>
        </motion.div>
      </motion.div>

      {/* ── PANEL DERECHO ── */}
      <motion.div
        initial={{ opacity: 0, x: 32 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        style={{
          width: "50%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "48px",
          position: "relative",
        }}
      >
        {/* Blob derecho */}
        <div style={{
          position: "absolute",
          top: -200,
          right: -200,
          width: 600,
          height: 600,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(255,255,255,0.03) 0%, transparent 70%)",
          filter: "blur(80px)",
          pointerEvents: "none",
        }} />

        <div style={{ width: "100%", maxWidth: 400, zIndex: 10 }}>

          {/* Nav */}
          <div style={{ marginBottom: 40 }}>
            <Link to="/" style={{ fontSize: 13, color: "#666", textDecoration: "none" }}>
              ← Home
            </Link>
          </div>

          {/* Eyebrow */}
          <p style={{ fontSize: 12, fontWeight: 600, color: "#6366f1", letterSpacing: "0.08em", textTransform: "uppercase", margin: "0 0 12px 0" }}>
            Iniciar sesión
          </p>

          <h2 style={{ fontSize: 32, fontWeight: 700, color: "#fff", letterSpacing: "-0.02em", margin: "0 0 8px 0" }}>
            Sign In
          </h2>
          <p style={{ fontSize: 15, color: "#666", margin: "0 0 36px 0" }}>
            Continúa construyendo conexiones significativas.
          </p>

          {/* Botón Google */}
          <button
            type="button"
            style={{
              width: "100%", height: 48,
              background: "linear-gradient(180deg, #1c1c1c 0%, #121212 100%)",
              border: "1px solid #222",
              borderRadius: 14,
              display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
              cursor: "pointer",
              marginBottom: 24,
              transition: "all 180ms ease",
              fontSize: 14, color: "#fff", fontWeight: 500,
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "#333"; e.currentTarget.style.background = "#1f1f1f"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "#222"; e.currentTarget.style.background = "linear-gradient(180deg, #1c1c1c 0%, #121212 100%)"; }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Continuar con Google
          </button>

          {/* Separador */}
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
            <div style={{ flex: 1, height: 1, background: "#1e1e1e" }} />
            <span style={{ fontSize: 12, color: "#444" }}>o</span>
            <div style={{ flex: 1, height: 1, background: "#1e1e1e" }} />
          </div>

          {/* Form */}
          <form onSubmit={handleLogin}>

            {/* Email */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: "block", fontSize: 13, fontWeight: 500, color: "#E5E7EB", marginBottom: 8 }}>
                Email
              </label>
              <input
                type="email"
                placeholder="alan.turing@itm.edu.co"
                value={email}
                onChange={e => setEmail(e.target.value)}
                style={{
                  width: "100%", height: 48,
                  background: "#141414",
                  border: "1px solid #2d2d2d",
                  borderRadius: 12,
                  padding: "0 16px",
                  fontSize: 14, color: "#fff",
                  outline: "none", boxSizing: "border-box",
                  transition: "all 180ms ease",
                }}
                onFocus={e => { e.currentTarget.style.borderColor = "#6366f1"; e.currentTarget.style.boxShadow = "0 0 0 3px rgba(99,102,241,0.12)"; }}
                onBlur={e => { e.currentTarget.style.borderColor = "#2d2d2d"; e.currentTarget.style.boxShadow = "none"; }}
              />
            </div>

            {/* Password */}
            <div style={{ marginBottom: 12 }}>
              <label style={{ display: "block", fontSize: 13, fontWeight: 500, color: "#E5E7EB", marginBottom: 8 }}>
                Contraseña
              </label>
              <div style={{ position: "relative" }}>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Tu contraseña"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  style={{
                    width: "100%", height: 48,
                    background: "#141414",
                    border: "1px solid #2d2d2d",
                    borderRadius: 12,
                    padding: "0 48px 0 16px",
                    fontSize: 14, color: "#fff",
                    outline: "none", boxSizing: "border-box",
                    transition: "all 180ms ease",
                  }}
                  onFocus={e => { e.currentTarget.style.borderColor = "#6366f1"; e.currentTarget.style.boxShadow = "0 0 0 3px rgba(99,102,241,0.12)"; }}
                  onBlur={e => { e.currentTarget.style.borderColor = "#2d2d2d"; e.currentTarget.style.boxShadow = "none"; }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{
                    position: "absolute", right: 14, top: "50%",
                    transform: "translateY(-50%)",
                    background: "transparent", border: "none",
                    color: "#666", cursor: "pointer",
                    display: "flex", alignItems: "center", padding: 0,
                  }}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <p style={{ fontSize: 12, color: "#ef4444", margin: "0 0 12px 0" }}>
                {error}
              </p>
            )}

            {/* Submit */}
            <motion.button
              type="submit"
              disabled={loading}
              whileHover={isReady && !loading ? { y: -2, boxShadow: "0 10px 30px rgba(99,102,241,0.3)" } : {}}
              whileTap={isReady && !loading ? { scale: 0.98 } : {}}
              style={{
                width: "100%", height: 48,
                borderRadius: 12,
                background: isReady ? "linear-gradient(135deg, #6366f1, #8b5cf6)" : "#191919",
                border: isReady ? "none" : "1px solid #282828",
                color: isReady ? "#fff" : "#666",
                fontSize: 14, fontWeight: 600,
                cursor: isReady && !loading ? "pointer" : "not-allowed",
                transition: "all 220ms ease",
                display: "flex", alignItems: "center", justifyContent: "center",
                marginBottom: 24,
              }}
            >
              {loading ? (
                <div style={{
                  width: 16, height: 16,
                  border: "2px solid rgba(255,255,255,0.3)",
                  borderTopColor: "#fff",
                  borderRadius: "50%",
                  animation: "spin 0.7s linear infinite",
                }} />
              ) : "Sign In"}
            </motion.button>
          </form>

          {/* Footer */}
          <p style={{ textAlign: "center", fontSize: 14, color: "#666", margin: 0 }}>
            ¿No tienes cuenta?{" "}
            <Link to="/register" style={{ color: "#6366f1", fontWeight: 600, textDecoration: "none" }}>
              Crear cuenta
            </Link>
          </p>
        </div>
      </motion.div>

      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @media (max-width: 768px) {
          .split-layout { flex-direction: column !important; }
          .split-left { width: 100% !important; height: 40vh !important; }
          .split-right { width: 100% !important; height: 60vh !important; }
        }
      `}</style>
    </div>
  );
}